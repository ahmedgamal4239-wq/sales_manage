# Employee access smoke checks

## Local run against the Replit development preview

Start the API Server, Sales Operations web, and Sales Operations Mobile workflows, then run:

```sh
pnpm --filter @workspace/scripts run verify-employee-browser
```

The script uses the running preview by default. Set `SMOKE_ORIGIN`, `SMOKE_API_ORIGIN`, or `SMOKE_MOBILE_URL` only when testing a different local environment. Chromium defaults to Replit's installed browser; set `CHROMIUM_PATH` when using another browser binary.

## Isolated CI/release check

The `Employee access smoke check` GitHub Actions workflow runs for pull requests, pushes to `main`/`master`, manual dispatch, and reusable workflow calls. It starts a fresh PostgreSQL 16 service, applies the current schema, and launches the API, Vite web app, and Expo web app. A short-lived, self-signed HTTPS proxy gives all three apps a shared browser origin. The proxy certificate, service logs, and processes are removed at the end of the run.

To require this check before changes merge, add **Employee access smoke check** as a required status check in the repository's branch protection or ruleset. A release workflow can also call `.github/workflows/employee-access-smoke.yml` with `workflow_call` and depend on the job before publishing.

The CI database and test-only session key are created for that run; they are not Replit Secrets and must never be replaced with production values. Browser contexts are closed without saving traces or screenshots. The smoke test creates random temporary employee accounts and a branch, then removes their database rows in `finally`; the entire CI database is discarded when the job ends.

For a local isolated run, start a disposable PostgreSQL instance, set `DATABASE_URL` to that new empty database, and run `pnpm --filter @workspace/scripts run ci:employee-browser`. Do not point this command at the development or production database: it pushes the schema. If the usual ports are already occupied, set `SMOKE_API_PORT`, `SMOKE_WEB_PORT`, `SMOKE_EXPO_PORT`, and `SMOKE_PROXY_PORT` to four unused ports. The command checks port availability before changing the database.

## Troubleshooting

- Ensure the job's PostgreSQL health check is green before schema push.
- If readiness times out, check the API, web, Expo, and proxy log sections in the failed job output. The shell runner prints bounded log tails only on failure.
- For a local run, verify the three Replit workflows are running and `REPLIT_EXPO_DEV_DOMAIN` is available.
- If CI's browser cannot launch, confirm `pnpm --filter @workspace/scripts exec playwright-core install --with-deps chromium` completed successfully and that the runner has not overridden `CHROMIUM_PATH`.
- The isolated check needs no manager credentials. It will fail explicitly if `DATABASE_URL` is missing or if any UI/API assertion fails.